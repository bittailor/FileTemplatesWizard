package freemarker.ext.rhino;

import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.Undefined;
import org.mozilla.javascript.UniqueTag;

import freemarker.ext.beans.BeansWrapper;
import freemarker.template.TemplateModel;
import freemarker.template.TemplateModelException;

/**
 * <p><font color="red">Experimental: no backward compatibility guarantees</font>;
 * any feedback is highly welcome!</p>
 * 
 * @author Attila Szegedi
 * @version $Id: RhinoWrapper.java,v 1.2.2.1 2006/07/31 11:34:52 szegedia Exp $
 */
public class RhinoWrapper extends BeansWrapper {

    public TemplateModel wrap(Object obj) throws TemplateModelException {
        if(obj instanceof Scriptable) {
            return getInstance(obj, RhinoScriptableModel.FACTORY);
        }
        // So our existence builtins work as expected.
        if(obj == Undefined.instance || obj == UniqueTag.NOT_FOUND || 
                obj == UniqueTag.NULL_VALUE) {
            return null;
        }
        return super.wrap(obj);
    }
}
